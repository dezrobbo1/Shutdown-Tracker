Shutdown Tracker current project sources
Created: 2026-08-13

Structure: research/ = research reports; reference/ = project history, design/review material, and real Microsoft Project XML reference schedules.

Excluded intentionally: application/repository archive Shutdown Tracker.zip and Concept Architecture Pack v1_2/v1_3 archives, because these are packaged repo/derived bundles rather than individual source documents.

Files:
- reference/AI Simulation Prototype Review.txt | 1148 bytes | SHA-256 0cafd7b20736e496dc1cb6fb9b49a01ca264a079a6165918ff82a60b4409ee61
- research/Built-in Communications for Shutdown Tracker.pdf | 153411 bytes | SHA-256 1ad13514bea765d8fe0048ff1cb2a2158d5ba95ebecfcc79d15173f8db328ce5
- research/deep-research-report.md | 35582 bytes | SHA-256 af03a4c19e0628f62c7d43c641486d223775bbb2077f7b7827bdb2489b22fde7
- reference/Live project tracking app.txt | 603 bytes | SHA-256 b409cbb0bf89bc01ac55bf6e5493fcf2f6932894934009a67f39fdf9e0911057
- reference/Live_Project_Tracker_Chat_Summary.pdf | 5549 bytes | SHA-256 7a93597523d7c4a9f47ae2d9cda544e76fcdf42cd5523b631a4bc01db4d3247d
- research/Microsoft Project import and export architecture for a shutdown live-tracking application.pdf | 170895 bytes | SHA-256 1707608f44ea194c42cbf8a524052a94dc7c298fd78df5ade57703ad6a489c27
- reference/Network Diagram for Design.txt | 11 bytes | SHA-256 334328a126b2f6fb3fe237920c70a4e64c64ca657fde58eee492f624684de3e4
- reference/microsoft-project-xml/NEW_5874946-KILN-WG047K-KLN021_v3 - Tagging setup change - tagging hours update - resource level 3(1).xml | 3474383 bytes | SHA-256 b7c14b631ecc7c15db7731e4a5159ecefe68aaa1c10e76262f84db6b8c37d3ca
- reference/microsoft-project-xml/NEW_6183209-CALCINER-WG050-CLW001(1).xml | 14280544 bytes | SHA-256 e952764512ae718e2701c0c79435025b07a5b09124fee4d51b385e92367ed18d
- reference/microsoft-project-xml/NEW_6477046-BOILER-WG110-BLB001(1).xml | 3734688 bytes | SHA-256 e6a3739976580e2144352011f818c0099c0dc0c278fb37a976c5b6a55fbc3420
- research/Planner-Configurable Operational Structures Derived from Microsoft Project XML.pdf | 239466 bytes | SHA-256 9566ea232f79da0af4572e06670a63422ea899a616e100ac8f7517c22361be72
- reference/Project Management Software.txt | 131 bytes | SHA-256 46f3b27767627d6bb81879b86f660ae0d3d0f90c74f7e604f62f58361a65823a
- reference/Project review continuation.txt | 8484 bytes | SHA-256 6256c8ab9c7011ea6c779116d07e574a2cb2908340ebfc9653ae8c963c71b091
- reference/Project Review.txt | 1045 bytes | SHA-256 7203b238cc9378233d43ae6be6296c079c82232f6daed252844290ce8220096f
- reference/Review zip file contents.txt | 7400 bytes | SHA-256 fc003430a95eb0928155717df37d7e2f5e71f9c013a89f04b307a988155a0ffa
- research/Shutdown Live-Tracking Platform Research.pdf | 121280 bytes | SHA-256 0a292773263e43bc956f4447dd4a66d7593d072eb48b8fa86194652afa72bab7
- reference/Shutdown Tracker Communications Layer Visual Review Brief.pdf | 183224 bytes | SHA-256 9ce8a774b37806f5068ed7d915400c8ef51eb1f732dc3f455874c321253eb8d9
- research/Shutdown Tracker Functionality, Possibilities, and Next Product Direction.pdf | 137158 bytes | SHA-256 da3d77ab6da9f1c9bff1e519189916a1e9513d71edd6d0ba6e91bff76cab7acb
- reference/Shutdown Tracker Messaging Design.txt | 4064 bytes | SHA-256 cd6c689ab2a9b18e3e89d93116c183ca1965171fe24c8b02cadcd9f78687924d
- reference/UI Design Render Request.txt | 2525 bytes | SHA-256 571a9cc90577310e37b256c323dccdcfa5345356e87a6689f3b00b4ca045da60
- research/UX and Operational Interaction Design Research Packet for Shutdown Tracker.pdf | 156005 bytes | SHA-256 01722190a43a793bd21574fb5cd1e2a6992412437202591af5fef536286c2442
- research/UX and UI Research for Shutdown Tracker.pdf | 158875 bytes | SHA-256 98f92c37269056e5fca37cd64013730b29077a515da7c469c3df127dc2932413
