# Configurable Critical Work Package Reporting for Shutdown Tracker

## Executive summary

The best design is to make **Critical Work Package reporting a configurable operational reporting layer**, not a calciner-specific workflow and not a scheduling feature. A **Critical Watchlist** should be a named list of reporting objects that can be sourced from imported Microsoft Project summary tasks, from multiple summary tasks grouped together, or from an explicitly defined manual group when the reporting scope crosses WBS boundaries. A **Critical WP** should default to “selected summary task plus all descendants,” because Microsoft Project XML exposes the hierarchy explicitly through `Summary`, `WBS`, `OutlineNumber`, `OutlineLevel`, `UID`, `ID`, and task-level `ExtendedAttribute` values, and MPXJ provides hierarchy traversal and stable unique IDs inside the imported file model. citeturn2view0turn6view0turn5view1turn4view0

The uploaded project context also confirms the intended product boundary: Microsoft Project remains the schedule authority, while Shutdown Tracker owns live execution tracking and reporting. The feature therefore must **not** calculate critical path, move dates, or live-feed changes into Project; it should only track user-defined critical work, collect updates, and optionally export a narrow whitelist of approved **leaf-task** actual/progress fields back to Microsoft Project in controlled batches. fileciteturn0file0 fileciteturn0file1 citeturn2view0turn5view3

The reporting model should center on a versioned **reporting policy** that supports: no cadence, ad hoc only, fixed interval, fixed times, shift-based, event-triggered, and custom cadence. Each due report becomes a **reporting period** with explicit due time, grace window, overdue state, and escalation logic. A user submission should be an immutable **Critical Update** record, optionally with multiple **Critical Update Lines** so one update can summarize multiple active child tasks under the same Critical WP. This preserves auditability when cadence or ownership changes mid-shutdown. citeturn8view1turn8view2

The UX should stay operational. In the Master Console, the feature belongs primarily in **Today → Critical Watch**, backed by a **Critical Watchlist page** and **Critical WP detail page**. On mobile, it belongs in **My Work** and **Today**, with a fast “Submit update” flow, visible due/overdue state, one-tap problem capture, camera-first evidence, and explicit sync states. The app should surface “needs attention now”: overdue reports, blocked critical work, unresolved safety/housekeeping issues, open actions, and unsynced updates. This fits the previously established UI direction and avoids Gantt/CPM creep. fileciteturn0file1 citeturn12view0turn12view2turn12view4turn8view0turn9view2

The most important implementation rule is this: **support site workflows through configuration and templates, not bespoke code paths**. That means the current “three calciner critical WPs with WhatsApp-style target/actual/delay/solution updates” should be a template, not the core domain model. The MVP should therefore include summary-task-based Critical WPs, optional multi-summary grouping, configurable cadence with “none” and “fixed interval/fixed times,” typed problems, assigned actions, evidence capture, offline queue visibility, and a basic Critical Watch report. It should exclude scheduling logic, custom workflow scripting, portfolio analytics, and live Microsoft Project updates. fileciteturn0file0 fileciteturn0file1

## Confirmed evidence and assumptions

### Confirmed evidence

From the Microsoft Project XML schema, task records in MSPDI/XML can expose the fields needed to build a generic Critical WP selection and reporting layer: `UID`, `ID`, `Name`, `WBS`, `OutlineNumber`, `OutlineLevel`, `Start`, `Finish`, `Summary`, `Critical`, `PercentComplete`, `ActualStart`, `ActualFinish`, `RemainingDuration`, `RemainingWork`, `Notes`, `PhysicalPercentComplete`, predecessor links, and per-task `ExtendedAttribute` values. Microsoft’s schema also defines project/task `ExtendedAttribute` structures for custom fields, including `FieldID`, `FieldName`, `Alias`, `ElemType`, and value lists. citeturn2view0turn6view0

From MPXJ’s own documentation, the library is designed around a neutral project data structure, can read `MPP`, `MSPDI`, and other schedule formats, can write `MSPDI`, and exposes both `getTaskByUniqueID()` and hierarchical traversal using `getChildTasks()`. MPXJ also distinguishes between task `ID` and `Unique ID`, and explicitly notes that the unique ID does not change within the file context. citeturn4view0turn4view1turn5view3

From the uploaded calciner XML reviewed in-session, the schedule contains the exact hierarchy pattern this feature needs: summary tasks such as **C2 Cyclone Top, Roof, & Inlet**, **D2 Stack**, **HV Roof / Inlet Top**, and **Furnace Bottom Vessel Opening**, each with descendant child tasks underneath. The same file also contains project-level custom fields with aliases such as **Work Discipline**, **Work Order No.**, **Operation Description**, **Workpack**, and **Assigned Department**, which makes optional mapping from Project custom fields feasible as a future enhancement.

From the uploaded WhatsApp exports reviewed in-session, the real-world reporting pattern is already split into two modes: a structured critical-update pattern using fields like **Task / Target / Actual / Delay / Solution**, and a more ad hoc problem stream covering safety, housekeeping, access, equipment, crane, utilities, and repair items, often with photos and informal action assignment. That is strong evidence that the app should implement **structured reporting plus a unified typed Problems model**, not a chat clone.

From web platform standards and browser docs, an offline-capable PWA should use **IndexedDB** for significant local structured data and blobs, **service workers** for offline shell/network interception, and the **Cache** API for request/response objects; Background Sync is useful but should remain progressive enhancement because it is not Baseline and does not work across some widely used browsers. citeturn12view4turn12view0turn12view3turn12view2

From WCAG 2.2, the platform needs keyboard operability, visible focus, minimum text contrast, non-text contrast for controls and states, explicit labels/instructions and error identification, status messages that assistive technologies can detect, and touch targets sized at least **24×24 CSS pixels** at Level AA, with **44×44 CSS pixels** still a strong ergonomic target from the AAA enhanced criterion. citeturn8view1turn7view4turn10view0turn9view2turn8view0

### Assumptions

The current calciner examples are representative of a broader pattern seen in shutdown execution: a small number of operationally critical work areas, each backed by many leaf tasks, with regular status reporting and a parallel stream of blockers and corrective actions.

The existing product boundary stays fixed: the new feature may monitor “critical work,” but it must not become a critical-path engine, dependency visualizer, or schedule optimizer.

The exported Microsoft Project file should continue to be treated as a planner-controlled artifact, not a near-real-time operational integration channel.

### Recommendations derived from the evidence

Use the imported Project hierarchy as the **source of candidate Critical WPs**, but treat the Critical WP itself as a **reporting object** that lives in Shutdown Tracker. This preserves compatibility with current workflows while avoiding schedule-authority confusion.

Support **three source modes** for a Critical WP: single summary task, multi-summary group, and explicit manual grouping. Make **single summary task plus descendants** the default and easiest path.

Treat “4-hour updates” as one template of a broader **reporting policy** system.

## Recommended product model

### Domain definitions

A **Critical Watchlist** is a named operational reporting list for one shutdown, area, or purpose. It owns membership, cadence defaults, escalation rules, visibility, and reporting outputs.

A **Critical Work Package** is the primary reporting object. It represents a bounded piece of critical execution scope. Its scope can come from one summary task, several summary tasks, or an explicit task set.

A **Critical Workstream** is an optional semantic grouping that crosses work package boundaries, used when leadership wants to track a restart train, energization sequence, vessel family, or campaign phase.

A **Reporting Policy** is the versioned rule set that determines whether updates are required and, if so, how due periods are generated.

A **Reporting Period** is one concrete due slot produced by a policy, such as “day shift close,” “14:00 update,” or “event: blocked more than 30 minutes.”

A **Critical Update** is an immutable report submission for a specific Critical WP/workstream and reporting period.

A **Critical Update Line** is an optional sub-entry used when one submission needs to report multiple active focal tasks or fronts underneath the same Critical WP.

A **Problem** is a typed issue record: delay, blocker, safety, housekeeping, access, permit, quality, resource, crane/lift, utility, weather, or other.

An **Action** is an assigned follow-up linked to a problem, Critical WP, update, or handover item.

**Evidence** is a photo or file linked to any of the above.

**Handover** is a generated or curated summary of unresolved issues, required next actions, and latest status at shift or day boundary.

### Recommended generic model

**Yes**, a Critical WP should support all three forms:
- a selected Microsoft Project summary task;
- a manually grouped set of tasks;
- a cross-boundary reporting group that spans several summary tasks.

But the product should strongly prefer this precedence order:

- **Default**: one imported summary task plus all descendants.
- **Then**: one Critical WP sourced from multiple summary tasks.
- **Finally**: explicit manual grouping of selected tasks when no clean summary structure exists.

That recommendation is grounded in the Project schema and MPXJ hierarchy model: the task tree and summary flag are first-class concepts, so using them is both simpler and less fragile than manual task-picking. citeturn2view0turn5view1

### Entity relationship model

```mermaid
erDiagram
    PROJECT_SNAPSHOT ||--o{ IMPORTED_TASK : contains
    CRITICAL_WATCHLIST ||--o{ CRITICAL_WATCHLIST_ITEM : contains
    CRITICAL_WATCHLIST_ITEM }o--|| CRITICAL_WORK_PACKAGE : references
    CRITICAL_WORK_PACKAGE ||--o{ CRITICAL_WORK_PACKAGE_SOURCE : sourced_from
    CRITICAL_WORK_PACKAGE ||--o{ REPORTING_POLICY_VERSION : governed_by
    REPORTING_POLICY_VERSION ||--o{ REPORTING_PERIOD : generates
    REPORTING_PERIOD ||--o{ CRITICAL_UPDATE : receives
    CRITICAL_UPDATE ||--o{ CRITICAL_UPDATE_LINE : contains
    CRITICAL_WORK_PACKAGE ||--o{ PROBLEM : affected_by
    CRITICAL_UPDATE ||--o{ PROBLEM : raises
    PROBLEM ||--o{ ACTION : creates
    CRITICAL_WORK_PACKAGE ||--o{ EVIDENCE : has
    CRITICAL_UPDATE ||--o{ EVIDENCE : attaches
    PROBLEM ||--o{ EVIDENCE : proves
    ACTION ||--o{ EVIDENCE : closes_with
    CRITICAL_WORK_PACKAGE ||--o{ HANDOVER_ENTRY : contributes
    AUDIT_EVENT }o--|| CRITICAL_UPDATE : audits
    AUDIT_EVENT }o--|| PROBLEM : audits
    AUDIT_EVENT }o--|| ACTION : audits
```

### Microsoft Project mapping approach

Use these imported fields for candidate selection and lineage:

| Project field | Use in Shutdown Tracker | Product rule |
|---|---|---|
| `UID` | primary imported task identity within a snapshot | read-only |
| `ID` | display/debug only; not durable across reshuffle | read-only |
| `Summary` | candidate summary-task filter | read-only |
| `OutlineNumber` | hierarchy prefix for descendant expansion | read-only |
| `OutlineLevel` | UI grouping and summary depth filtering | read-only |
| `WBS` | alternate grouping/display | read-only |
| `Name` | display/search/match assist | read-only |
| `Start`/`Finish` | baseline planned times for comparison | read-only |
| `ActualStart`/`ActualFinish` | approved export candidates on leaf tasks only | controlled write-back |
| `PercentComplete` | approved export candidate on leaf tasks only | controlled write-back |
| `Notes` | import-only context; do not overwrite | read-only |
| `ExtendedAttribute` | optional mapping for watchlists/workstreams | import + configuration only |

The selection algorithm should be:

1. Import the full Project snapshot.
2. Show candidate summary tasks where `Summary=true`, excluding project root and optionally filtering by minimum descendant count or discipline. citeturn2view0
3. When a user selects a summary task as a Critical WP, expand scope to **all descendants by hierarchy**. This can be done either by `OutlineNumber` prefix rules in stored data or via MPXJ child-task traversal in import-time processing. citeturn2view0turn5view1
4. Persist each source task link in `critical_work_package_source`.
5. If one reporting group spans multiple summaries, attach multiple source rows to one Critical WP.
6. If manual grouping is required, attach explicit task references to that Critical WP and mark source mode as `MANUAL`.

### Scope rules for nested summaries

If a selected summary contains another selected summary beneath it, the UI should force one of two explicit behaviors:

- **Inclusive parent mode**: the parent Critical WP includes all descendants, including the nested summary tree.
- **Partitioned mode**: the nested summary is carved out as its own Critical WP, and the parent scope excludes that subtree.

Do not let this happen implicitly. Hidden double-counting will confuse every report.

### Reporting policy model

A reporting policy should be a versioned configuration object with these modes:

| Mode | When to use | How periods are generated |
|---|---|---|
| None | critical for visibility only | no due periods |
| Ad hoc | update whenever something changes | user-initiated only |
| Fixed interval | every N hours/minutes | rolling periods from effective start |
| Fixed times | e.g. 06:00 / 10:00 / 14:00 | calendar slots |
| Shift-based | shift start/end/handover | shift calendar |
| Event-triggered | start, blocked, resume, complete, missed target | event engine |
| Custom | site-specific rule composition | configured generator |

Recommended configuration hierarchy:
- watchlist default policy;
- Critical WP override policy;
- temporary override for a bounded date/time window.

If cadence changes mid-shutdown, do **not** mutate old periods. Create a new `reporting_policy_version` effective from a timestamp, generate new periods forward from there, and keep historical Critical Updates linked to the policy version under which they were due. That is the cleanest way to keep the audit trail intelligible.

### Reporting cadence timeline

```mermaid
timeline
    title Example fixed-times policy for a Critical WP
    06:00 : Period opens
          : Due at 06:00
    06:15 : Grace window ends
    06:16 : State becomes overdue
    06:30 : Escalate to supervisor
    10:00 : Next period due
    10:15 : Grace window ends
    10:16 : Overdue again if not submitted
```

### Critical Update structure

A submitted Critical Update should have a **header** and optional **lines**.

**Header**
- watchlist
- Critical WP
- reporting period
- policy version
- due time
- submitted time
- submitted by
- owner/team
- update mode: scheduled or ad hoc
- high-level status: on-track / at-risk / delayed / blocked / complete
- current blocker summary
- next target
- completeness state
- review state
- correction/supersedes metadata

**Line**
- current focus / active child task
- linked task UID if known
- target label + value
- actual label + value
- delay / issue text
- solution / next action text
- percent or physical progress if used
- linked problem IDs
- linked action IDs
- linked evidence IDs

Recommendation: submit updates **per Critical WP per reporting period**, with **multiple lines optional**. That matches the real shutdown reporting pattern better than forcing one update per child task, while still allowing structured detail.

Submitted updates should be immutable. If a correction is needed, create a **superseding correction record** rather than editing the original in place.

## UX and reporting design

### Master Console placement

The feature should live in three places:

- **Today → Critical Watch** for operational triage.
- **Tasks** for context and task drill-down.
- **Problems** for issue/action management.

The default **Today → Critical Watch** panel should show only high-signal fields:

| Field | Why it belongs |
|---|---|
| Critical WP name | scanability |
| status/RAG | immediate triage |
| next update due | cadence control |
| overdue age | escalation |
| current target vs actual summary | reporting signal |
| blocker count | operational risk |
| open action count | accountability |
| safety/housekeeping flags | control-room visibility |
| last update time and author | trust/audit |
| sync warning if pending/failed | field trust |

What should **not** appear by default:
- full task lists
- dense Gantt bars
- dependency graphs
- long history tables
- cost/resource grids
- export details unrelated to the current watchlist

### Sample wireframe sketches

#### Master Console Today critical watch

```text
+----------------------------------------------------------------------------------+
| Today | Tasks | Problems | Evidence | Exports                        [Planner]   |
+----------------------------------------------------------------------------------+
| Shutdown: PJ1 Calciner MOH     Shift: Day     Last sync: 09:58      3 overdue    |
+----------------------------------------------------------------------------------+
| CRITICAL WATCH                                                                  |
|----------------------------------------------------------------------------------|
| [RED]  C2 Cyclone Top, Roof & Inlet      Due 10:00   Overdue 18m                 |
|       Focus: Rig & lower Brokk           Target: access complete                  |
|       Actual: 95%                        Problems: 2      Actions: 3     📷 6     |
|       Owner: Refrac Sup                  Last update: 09:12 Craig                 |
|       [Open detail] [Submit correction] [Log problem]                            |
|----------------------------------------------------------------------------------|
| [AMBER] D2 / HV & FR Top                 Due 14:00   On time                      |
|       Focus: Vac out HV bottom           Target: 100%  Actual: 60%               |
|       Problems: 1      Actions: 1        Safety: 0     📷 2                       |
|----------------------------------------------------------------------------------|
| [GREEN] Furnace Bottom                   No cadence   Ad hoc only                 |
|       Focus: Wicket removal completed    Last update: 08:44 Reno                  |
+----------------------------------------------------------------------------------+
| Open critical problems      Open safety items      Failed mobile uploads         |
+----------------------------------------------------------------------------------+
```

#### Mobile update flow

```text
+----------------------------------+
| < My Work        Critical Update |
+----------------------------------+
| Critical WP                      |
| [D2 / HV & FR Top           v ]  |
| Update type   [Scheduled 10:00]  |
| Status        [At risk       v ] |
| Current focus                     |
| [Vac out HV bottom            ]  |
| Planned focus / target            |
| [100% vac complete            ]  |
| Current status / actual           |
| [60% complete, heavy buildup  ]  |
| Delay / blocker                   |
| [Lots in there                ]  |
| Next action / solution            |
| [Continue vac, request extra  ]  |
| Owner           [Reno         ]  |
| + Link problem   + Add photo       |
|----------------------------------|
| [Save draft]   [Queue offline]   |
| [Submit]                          |
| Sync state: Pending upload        |
+----------------------------------+
```

### Mobile behavior

The mobile app should put Critical WPs in **My Work** when the user owns them or has actions linked to them. Each card should show:

- name
- due/overdue state
- status
- next update due
- blocked flag
- open actions count
- pending sync indicator

The update flow should be short, keyboard-first, and camera-ready. A user should be able to file an update in under a minute when network is poor.

### Problems, actions, and evidence UX

Use one unified **Problems** model with typed categories. The WhatsApp-style “general problems” workflow should become a structured issue register, not a chat timeline.

Minimum problem fields:
- type
- title
- linked Critical WP or task
- severity
- owner
- due/review time
- status
- impact on reporting or execution
- evidence required?
- handover flag

Minimum action fields:
- description
- owner/team
- due time
- priority
- status
- parent problem
- close-out note
- close-out evidence requirement

Evidence capture should be **camera first**. On mobile:
- take photo
- preview thumbnail
- add optional caption/tag
- choose linked entity
- save locally
- show queue state: pending / failed / synced

This design aligns with service-worker/PWA constraints and with WCAG status-message requirements: sync state and validation state should be visible and programmatically detectable, not hidden in toasts alone. citeturn12view0turn12view3turn8view2

### Reporting outputs

The reporting layer should produce five standard outputs:

| Output | Primary audience | Format |
|---|---|---|
| Critical Watch update report | control room | PDF, web, clipboard |
| Reporting-period report | shift reporting | PDF, CSV |
| Handover report | outgoing/incoming shift | PDF, web |
| Management summary | managers | PDF, CSV |
| Open problem/action report | supervisors/coordinators | web, CSV |

Do not hardcode the labels **Target / Actual / Delay / Solution**. Make them template labels. The underlying semantic fields should remain stable, but presentation labels can vary:
- Planned focus / Intended progress
- Current status / Achieved progress
- Blocker / Issue
- Recovery action / Next action

### Microsoft Project export eligibility

Only these should be eligible for controlled export, and only on **leaf tasks**:
- actual start
- actual finish
- percent complete
- one mutually exclusive effort expression set, if required by the export decision

These should remain inside Shutdown Tracker:
- watchlists
- reporting periods
- Critical Updates
- problem/action records
- evidence/photos
- handover notes
- summary-task watch states
- report status or overdue state

That rule avoids writing operational reporting noise back into the schedule model.

## Data, permissions, and offline model

### Data model recommendation

Use **immutable records plus mutable projections**.

| Entity | Purpose | Mutability | Notes |
|---|---|---|---|
| `project_snapshot` | one imported Project state | immutable | every import is new |
| `imported_task` | imported Project task row | immutable per snapshot | keyed by snapshot + UID |
| `critical_watchlist` | named watchlist | mutable metadata + audited changes | current config object |
| `critical_watchlist_item` | membership row | mutable + audited | links watchlist to WP/workstream |
| `critical_work_package` | reporting object | mutable config + audited | not tied to one import only |
| `critical_work_package_source` | links WP to imported task scopes | immutable-per-link, supersedable | source mode + scope |
| `reporting_policy_version` | cadence rules | immutable | new row on any change |
| `reporting_period` | due slot | immutable | generated from policy |
| `reporting_due_state` | current due/submitted/late/missed projection | mutable | server-authoritative |
| `critical_update` | submitted report header | immutable | corrections supersede |
| `critical_update_line` | line detail | immutable | child rows |
| `problem` | issue header | immutable create + status event history | use projection for current state |
| `action` | assigned follow-up | immutable create + status event history | projection for current state |
| `evidence` | photo/file metadata | immutable | binary in object storage |
| `handover_entry` | shift/day handover item | immutable | can reference live objects |
| `report_export` | generated report artifact | immutable | includes parameters and hash |
| `audit_event` | append-only audit trail | immutable | every sensitive change |

Recommendation: do **not** overwrite submitted updates or destructive-delete evidence metadata. Use superseding records, soft removal markers, and audit events.

### Re-import handling

Every Microsoft Project file import should create a new immutable snapshot. To reconnect existing Critical WPs to the revised schedule, use this lineage strategy:

1. same schedule family + same imported task `UID`;
2. if custom reporting key exists, match by explicitly configured `ExtendedAttribute`;
3. else use prior source scope + parent lineage + name similarity as a manual-review suggestion only.

This is why `critical_work_package_source` should store not just current task links, but also the source mode and accepted lineage history.

### Permissions model

| Capability | Admin | Planner | Shutdown control | Coordinator | Supervisor | Field user | Viewer |
|---|---|---:|---:|---:|---:|---:|---:|
| Create/edit watchlist | yes | yes | yes | limited | no | no | no |
| Select Critical WPs | yes | yes | yes | limited | no | no | no |
| Change reporting policy | yes | yes | yes | limited | no | no | no |
| Submit update | yes | yes | yes | yes | yes | assigned only | no |
| Edit draft | yes | yes | yes | yes | yes | own only | no |
| Correct submitted update | yes | yes | yes | yes | supervisor own area | no | no |
| Create problem | yes | yes | yes | yes | yes | yes | no |
| Assign action | yes | yes | yes | yes | yes | request only | no |
| Close action/problem | yes | yes | yes | yes | yes | own task if allowed | no |
| Upload evidence | yes | yes | yes | yes | yes | yes | no |
| Generate/export reports | yes | yes | yes | yes | yes | limited | view only |
| Export to Project | yes | planner only | no | no | no | no | no |

### Audit model

Audit events should include:
- watchlist created/edited
- Critical WP source added/removed
- policy version changed
- reporting period generated/closed/missed
- update drafted/submitted/corrected/superseded
- problem created/changed/closed
- action assigned/reassigned/completed/verified
- evidence uploaded/linked/unlinked
- handover generated
- report exported
- Project export batch approved/generated

### Offline and sync implications

The browser/offline model should be:

- **IndexedDB**: watchlists, tasks, due periods, draft updates, queued actions, queued problems, evidence metadata, local IDs. IndexedDB is suited to large structured datasets and can store blobs/files. citeturn12view4turn11view0
- **Service worker**: offline shell, request interception, cache population, stale-safe fallback. Service workers sit between app, browser, and network, and are the right control point for offline behaviors. citeturn12view0turn13view0
- **Cache API**: app shell and read-mostly request/response pairs. citeturn12view3
- **Background Sync**: optional only; do not make correctness depend on it because support is limited. citeturn12view2

Recommended user-visible sync states:
- offline
- draft saved locally
- queued
- syncing
- synced
- failed
- conflict needs review

If a due time passes while offline, the app should not fake on-time submission. It should store:
- captured_at_local
- submitted_at_server
- due_at
- late_reason = offline_pending if applicable

This is essential for trust.

## MVP, risks, and tasks

### MVP scope

The minimum viable feature should include:

- create Critical Watchlist
- select one or more summary tasks as Critical WPs
- auto-include descendants
- allow one Critical WP to reference multiple summary tasks
- configure policy: none, ad hoc, fixed interval, fixed times
- generate reporting periods
- submit Critical Update with optional multiple lines
- link problems/actions/evidence
- show Today → Critical Watch
- show due/overdue state
- basic PDF/CSV report
- offline drafts and visible pending queue on mobile

Defer to later:
- arbitrary leaf-task grouping UI
- shift-calendar engine
- event-triggered automation beyond simple rules
- workflow scripting
- complex escalation automations
- AI summaries or predictions
- scheduler-like visualizations
- portfolio reporting across multiple shutdowns

### Key risks and mitigations

| Risk | Level | Why it matters | Mitigation |
|---|---|---|---|
| Bespoke workflow creep | critical | calciner terms infect product model | neutral names + templates only |
| Critical-path creep | critical | product drifts into scheduling | hard rule: watchlists only, no CPM |
| Summary-task export mistakes | high | corrupts schedule authority | export leaf tasks only |
| Too much configuration | high | hard to deploy | ship opinionated templates |
| Too little configuration | high | teams fall back to WhatsApp | support policy + labels + source modes |
| WhatsApp fallback continues | high | data fragmentation | make update/problem capture faster than chat |
| Offline “pending” mistaken as “submitted” | critical | trust failure | explicit queue states everywhere |
| Report edits after submission | high | audit loss | immutable updates + correction records |
| Photos attached to wrong issue | medium | weak evidence chain | enforce link target before submit |
| Action ownership unclear | high | lost accountability | required owner + due time + escalation |
| Mobile overload | medium | poor field adoption | shortest possible form + role pruning |
| Dashboard bloat | high | signal drowned by noise | Critical Watch panel only on landing |

### First twenty product, design, and engineering tasks

1. Lock glossary: Critical Watchlist, Critical WP, Critical Workstream, Reporting Policy, Reporting Period, Critical Update.
2. Add feature ADR to the concept pack.
3. Formalize the “no scheduling / no live Project feed” rule in product docs.
4. Define source modes: summary, multi-summary, manual.
5. Design `critical_work_package_source` and lineage rules.
6. Extend import pipeline to persist summary-task candidates and descendant scopes.
7. Prototype candidate-selection UI on imported task tree.
8. Define reporting policy schema and versioning rules.
9. Build reporting-period generator for none/ad hoc/fixed interval/fixed times.
10. Design Critical Update header and line schemas.
11. Define typed Problems taxonomy and action states.
12. Define evidence metadata schema and object-storage path rules.
13. Create Today → Critical Watch low-fidelity wireframe.
14. Create Critical WP detail low-fidelity wireframe.
15. Create mobile submit-update wireframe and validation rules.
16. Implement offline draft storage in IndexedDB.
17. Implement queued event model with local IDs and idempotency keys.
18. Build visible Sync Queue UI and state chips.
19. Build PDF/CSV report prototype for one watchlist.
20. Build approval boundary so only planner-approved leaf-task actuals can be exported to MSPDI.

## ADR draft

### Status

Proposed.

### Context

Shutdown Tracker needs to support site-specific critical-work reporting patterns, including summary-task-based reporting groups and cadence-based updates, without becoming bespoke to one asset type or taking over scheduling duties from Microsoft Project. Microsoft Project XML and MPXJ provide hierarchy and custom-field support that can be used to source reporting groups from schedule data, while the app’s operational UX requires visible due/overdue state, typed issues, evidence, and offline-safe submission. citeturn2view0turn6view0turn4view0turn5view1turn12view4turn12view0

### Decision

Adopt a **Configurable Critical Work Package Reporting Model** with these rules:

- A Critical WP is a Shutdown Tracker reporting object, not a scheduling object.
- A Critical WP may be sourced from:
  - one imported summary task plus all descendants;
  - multiple summary tasks;
  - an explicit manual grouping.
- Critical WPs are organized in one or more Critical Watchlists.
- Reporting cadence is governed by versioned reporting policies that support:
  - none;
  - ad hoc;
  - fixed interval;
  - fixed times;
  - shift-based;
  - event-triggered;
  - custom.
- A submitted Critical Update is immutable and may contain multiple lines.
- Problems, actions, evidence, and handover entries are linked to Critical WPs and/or updates through typed records.
- Microsoft Project remains the schedule authority.
- The feature must not calculate critical path, change logic, or live-feed into Project.
- Only planner-approved leaf-task progress/actual fields remain eligible for batched Project export.

### Consequences

This design supports the current calciner use case, but keeps the product generic. It increases initial modeling complexity slightly, because watchlists, source scopes, and policy versions become first-class entities. However, it sharply reduces bespoke-code risk, improves auditability, and provides a clean boundary between schedule import and execution reporting.

### Open questions

The main open design questions are:

- Should MVP include fully arbitrary leaf-task manual grouping, or only single-summary and multi-summary source modes?
- Should event-triggered reporting in MVP be limited to simple task-state triggers?
- Should supervisor review be required for all submitted Critical Updates or only corrected/late updates?
- Should evidence be mandatory by default for safety closure and optional elsewhere, or fully template-driven from day one?

### Recommended answer to those open questions

For MVP:
- include single-summary and multi-summary sources;
- defer arbitrary leaf grouping;
- support simple event triggers later;
- require review only for corrected or planner-sensitive updates;
- make safety/quality closure evidence mandatory by template default.

## Open questions for v1.3 merge

Use the following decisions unless business review insists otherwise:

- **Default Critical WP source**: summary task plus descendants.
- **Generic feature name**: Critical Watchlist and Critical Work Package.
- **Default cadence**: none; templates can set 4-hour, hourly, shift-based, or fixed times.
- **Default update unit**: one Critical Update per WP per period, with optional lines.
- **Project write-back**: leaf-task only.
- **Offline truth rule**: queued is not submitted.
- **Evidence rule**: required for safety/quality close-out by template.
- **Template philosophy**: configuration over custom code.

That gives you a feature that can reproduce the current three-critical-WP workflow, but still scale to other shutdown types without trapping the product in one site’s language or one planner’s structure.